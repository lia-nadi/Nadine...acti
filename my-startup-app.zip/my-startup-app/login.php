<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login y Registro - My Startup App</title>
    <link rel="stylesheet" href="css/login_styles.css">
    <style>
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>    
    <main>
        <div class="contenedor__todo">
            <div class="caja__trasera">
                <div>
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para entrar en la página</p>
                    <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                </div>
                <div>
                    <h3>¿Aún no tienes una cuenta?</h3>
                    <p>Regístrate para que puedas iniciar sesión</p>
                    <button id="btn__registrarse">Regístrate</button>
                </div>
            </div>

            <!--Formulario de Login y Registro-->
            <div class="contenedor__login-register">
                <!--Login-->
                <form action="php/login.php" method="POST" class="formulario__login">
                    <h2>Iniciar Sesión</h2>
                    <input type="email" placeholder="Correo Electrónico" name="email" required>
                    <input type="password" placeholder="Contraseña" name="password" required>
                    <button type="submit">Entrar</button>
                </form>

                <!--Register-->
                <form action="php/register.php" method="POST" class="formulario__register">
                    <h2>Registrarse</h2>
                    <?php
                    if (isset($_SESSION['error'])) {
                        echo "<p class='error'>" . $_SESSION['error'] . "</p>";
                        unset($_SESSION['error']);
                    }

                    if (isset($_SESSION['success'])) {
                        echo "<p class='success'>" . $_SESSION['success'] . "</p>";
                        unset($_SESSION['success']);
                    }
                    ?>
                    <input type="text" placeholder="DNI" name="dni" required>
                    <input type="text" placeholder="Nombre" name="name" required>
                    <input type="email" placeholder="Correo Electrónico" name="email" required>
                    <input type="password" placeholder="Contraseña" name="password" required>
                    <input type="password" placeholder="Repetir Contraseña" name="password_confirm" required>
                    <label>
                        <input type="checkbox" name="privacy_policy" required>
                        Acepto las políticas de privacidad
                    </label>
                    <button type="submit">Registrarse</button>
                </form>
            </div>
        </div>
    </main>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="js/login.js" defer></script>
</body>
</html>
