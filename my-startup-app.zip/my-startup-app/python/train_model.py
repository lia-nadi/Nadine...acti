import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
import xgboost as xgb
from sklearn.metrics import r2_score
import joblib

# Leer el archivo CSV procesado
data = pd.read_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'processed_data.csv'))

# Verificar las columnas del DataFrame
print("Columnas del DataFrame:", data.columns)

# Análisis de correlaciones
correlation_matrix = data.corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
plt.title('Matriz de correlación')
plt.show()

# Distribución de la variable objetivo 'Popularidad'
sns.histplot(data['Popularidad'], kde=True)
plt.title('Distribución de Popularidad')
plt.show()

# Boxplot de la variable objetivo 'Popularidad'
sns.boxplot(data=data['Popularidad'])
plt.title('Boxplot de Popularidad')
plt.show()

# Análisis de outliers en otras características
features = ['Fondos recibidos (USD)', 'Número de empleados', 'Años en el mercado', 
            'Evaluación del cliente', 'Ingresos anuales (USD)', 'Número de usuarios', 
            'Seguidores en redes sociales']

for feature in features:
    sns.boxplot(data=data[feature])
    plt.title(f'Boxplot de {feature}')
    plt.show()

# Remover outliers
for feature in features:
    Q1 = data[feature].quantile(0.25)
    Q3 = data[feature].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    data = data[(data[feature] >= lower_bound) & (data[feature] <= upper_bound)]

# Aquí vamos a suponer que la columna 'Popularidad' es la métrica de éxito que queremos predecir
success_metric_column = 'Popularidad'

# Remover características con baja correlación con 'Popularidad'
correlation_matrix = data.corr()  # Recalcular la matriz de correlación después de eliminar outliers
threshold = 0.1
low_correlation_features = correlation_matrix[abs(correlation_matrix[success_metric_column]) < threshold].index
data.drop(low_correlation_features, axis=1, inplace=True)

# Verificar las nuevas columnas después de eliminar las de baja correlación
print("Columnas después de eliminar las de baja correlación:", data.columns)

if success_metric_column in data.columns:
    # Separar las características (X) y la variable objetivo (y)
    X = data.drop(success_metric_column, axis=1)
    y = data[success_metric_column]
    
    # Dividir los datos en conjuntos de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Normalizar los datos
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Guardar el scaler para uso futuro
    models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'models')
    os.makedirs(models_dir, exist_ok=True)
    joblib.dump(scaler, os.path.join(models_dir, 'scaler.pkl'))
    
    # Entrenar el modelo RandomForest
    model = RandomForestRegressor(random_state=42)
    model.fit(X_train, y_train)
    
    # Guardar el modelo entrenado
    joblib.dump(model, os.path.join(models_dir, 'randomforest_model.pkl'))
    
    print(f"Modelo entrenado y guardado como 'randomforest_model.pkl' en {models_dir}")
else:
    print(f"La columna '{success_metric_column}' no se encuentra en el DataFrame")
