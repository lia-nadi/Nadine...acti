import os
from flask import Flask, request, jsonify, send_from_directory, render_template
import joblib
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import base64
import io
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Configuración de subida de archivos
PDF_FOLDER = 'pdf_uploads'
app.config['PDF_FOLDER'] = PDF_FOLDER
if not os.path.exists(PDF_FOLDER):
    os.makedirs(PDF_FOLDER)

# Ruta absoluta del modelo y scaler
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model_dir = os.path.join(BASE_DIR, 'python', 'models')
model_paths = {
    'randomforest': os.path.join(model_dir, 'randomforest_model.pkl'),
    'ridge': os.path.join(model_dir, 'ridge_model.pkl'),
    'xgboost': os.path.join(model_dir, 'xgboost_model.pkl')
}
scaler_path = os.path.join(model_dir, 'scaler.pkl')

# Verificar la existencia de los archivos del modelo y el escalador
if not os.path.exists(scaler_path):
    raise FileNotFoundError(f"No se encuentra el archivo del escalador en: {scaler_path}")

for name, path in model_paths.items():
    if not os.path.exists(path):
        raise FileNotFoundError(f"No se encuentra el archivo del modelo {name} en: {path}")

# Cargar el scaler
scaler = joblib.load(scaler_path)

# Cargar modelos
models = {name: joblib.load(path) for name, path in model_paths.items()}

@app.route('/')
def index():
    return send_from_directory(BASE_DIR, 'investment.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Obtener datos del formulario
        name = request.form['name']
        sector = request.form['sector']
        popularity = int(request.form['popularity'])
        growth_time = int(request.form['growthTime'])
        region = request.form['region']
        file = request.files['file']

        # Guardar archivo PDF subido
        if file and file.filename.split('.')[-1].lower() == 'pdf':
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['PDF_FOLDER'], filename)
            file.save(filepath)
        else:
            return jsonify({'error': 'Solo se permiten archivos PDF'}), 400

        # Generar datos para las características necesarias para la predicción
        data = {
            'Fondos recibidos (USD)': np.random.randint(50000, 1000000),
            'Número de empleados': np.random.randint(10, 500),
            'Años en el mercado': np.random.randint(1, 10),
            'Evaluación del cliente': np.random.uniform(1, 5),
            'Ingresos anuales (USD)': np.random.randint(100000, 5000000),
            'Número de usuarios': np.random.randint(1000, 1000000),
            'Seguidores en redes sociales': np.random.randint(1000, 1000000),
            'Popularidad': popularity,
            'Tiempo de crecimiento': growth_time
        }

        input_data = pd.DataFrame([data])
        input_data = pd.get_dummies(input_data, drop_first=True)

        # Añadir columnas faltantes con ceros si es necesario
        for col in scaler.feature_names_in_:
            if col not in input_data.columns:
                input_data[col] = 0

        # Reordenar las columnas según el scaler original
        input_data = input_data[scaler.feature_names_in_]

        # Normalizar los datos de entrada
        input_data_normalized = scaler.transform(input_data)

        # Realizar el pronóstico con cada modelo
        predictions = {name: model.predict(input_data_normalized)[0] for name, model in models.items()}

        # Seleccionar la predicción basada en RandomForest (puedes cambiar esto según tus necesidades)
        prediction_label = "bueno" if predictions['randomforest'] > 0.5 else "malo"

        # Generar gráfico
        plt.figure(figsize=(10, 6))
        plt.bar(input_data.columns, models['randomforest'].feature_importances_)
        plt.title('Importancia de las características')
        plt.xticks(rotation=90)
        plt.tight_layout()

        # Guardar gráfico en memoria
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        image_base64 = base64.b64encode(buf.read()).decode('utf-8')
        buf.close()

        chart_data = {
            'labels': input_data.columns.tolist(),
            'datasets': [{
                'label': 'Importancia de las características',
                'data': models['randomforest'].feature_importances_.tolist(),
                'backgroundColor': 'rgba(75, 192, 192, 0.2)',
                'borderColor': 'rgba(75, 192, 192, 1)',
                'borderWidth': 1
            }]
        }

        # Devolver el resultado como JSON
        return jsonify({'prediction': prediction_label, 'chartData': chart_data, 'chartImage': image_base64})
    except Exception as e:
        print(f"Error durante la predicción: {e}")
        return jsonify({'error': f"Error durante la predicción: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

