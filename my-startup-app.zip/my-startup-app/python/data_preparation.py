import os
import pandas as pd

# Proporcionar la ruta correcta al archivo CSV usando barras diagonales
file_path = 'D:/FINESI/7 semestre/ingenieria de software/proyecto..._/my-startup-app/python/Startups_Populares_en_Per___Actualizado_.csv'

# Definir la ruta de salida para el archivo procesado
output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
output_file = os.path.join(output_dir, 'processed_data.csv')

try:
    # Leer el archivo CSV
    data = pd.read_csv(file_path)
    
    # Mostrar las primeras filas para entender la estructura
    print(data.head())
    
    # Preprocesamiento básico
    data = data.dropna()  # Eliminar filas con valores nulos
    data = pd.get_dummies(data, drop_first=True)  # Convertir variables categóricas a numéricas

    # Crear la carpeta de salida si no existe
    os.makedirs(output_dir, exist_ok=True)
    
    # Guardar el dataset procesado
    data.to_csv(output_file, index=False)
    print(f"Archivo procesado guardado como '{output_file}'")
except FileNotFoundError:
    print(f"El archivo en la ruta especificada no fue encontrado: {file_path}")
except Exception as e:
    print(f"Ocurrió un error al procesar el archivo: {e}")
