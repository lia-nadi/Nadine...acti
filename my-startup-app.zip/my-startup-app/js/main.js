function googleLogin() {
    // Aquí va la lógica para iniciar sesión con Google
    alert("Iniciar sesión con Google aún no está implementado.");
}
