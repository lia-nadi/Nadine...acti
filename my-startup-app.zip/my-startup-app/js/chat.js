document.addEventListener('DOMContentLoaded', function() {
    const chatbotIcon = document.getElementById('chatbot');
    const chatbotWindow = document.getElementById('chatbot-window');
    const messageInput = document.getElementById('chatbot-input');
    const sendButton = document.getElementById('chatbot-send');
    const messagesContainer = document.getElementById('chatbot-messages');

    // Toggle chatbot window visibility
    chatbotIcon.addEventListener('click', () => {
        chatbotWindow.style.display = chatbotWindow.style.display === 'none' ? 'block' : 'none';
    });

    // Send message
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    function sendMessage() {
        const messageText = messageInput.value.trim();
        if (messageText === '') return;

        addMessage('user', messageText);
        messageInput.value = '';

        // Simulate bot response
        setTimeout(() => {
            const botResponse = getBotResponse(messageText);
            addMessage('bot', botResponse);
        }, 1000);
    }

    function addMessage(sender, text) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', sender);
        messageElement.textContent = text;
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    function getBotResponse(userMessage) {
        // Here you can add more complex bot responses
        return 'This is a static response from the bot. You said: ' + userMessage;
    }
});
