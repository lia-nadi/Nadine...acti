document.addEventListener('DOMContentLoaded', function() {
    const btnIniciarSesion = document.getElementById("btn__iniciar-sesion");
    const btnRegistrarse = document.getElementById("btn__registrarse");
    const formulario_login = document.querySelector(".formulario__login");
    const formulario_register = document.querySelector(".formulario__register");
    const contenedor_login_register = document.querySelector(".contenedor__login-register");

    if (btnIniciarSesion && btnRegistrarse && formulario_login && formulario_register) {
        btnIniciarSesion.addEventListener("click", iniciarSesion);
        btnRegistrarse.addEventListener("click", register);
        window.addEventListener("resize", anchoPage);

        function anchoPage() {
            if (window.innerWidth > 850) {
                contenedor_login_register.style.left = "10px";
            } else {
                contenedor_login_register.style.left = "0px";
            }
        }

        anchoPage();

        function iniciarSesion() {
            formulario_register.style.display = "none";
            formulario_login.style.display = "block";
        }

        function register() {
            formulario_register.style.display = "block";
            formulario_login.style.display = "none";
        }
    } else {
        console.error('Uno o más elementos no se encontraron en el DOM');
    }
});
