<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios - My Startup App</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        .navbar {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .intro-section {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            padding: 60px 0;
        }
        .service-card {
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        .testimonial {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .resources a {
            color: #6e8efb;
            text-decoration: none;
        }
        .resources a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="images/logo.png" alt="Logo" class="logo-navbar">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link nav-btn" href="index.html">INICIO</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle nav-btn" href="#" id="servicesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                SERVICIO
                            </a>
                            <div class="dropdown-menu" aria-labelledby="servicesDropdown">
                                <a class="dropdown-item" href="services.html?filter=incubadora">Incubadora</a>
                                <a class="dropdown-item" href="services.html?filter=aceleradora">Aceleradora</a>
                                <a class="dropdown-item" href="services.html?filter=inversión angel">Inversión Angel</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn" href="investment.html">INVERSIÓN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn" href="contact.html">CONTACTOS</a>
                        </li>
                        
                    </ul>
                    <form class="form-inline ml-3">
                        <input class="form-control mr-sm-2" type="search" placeholder="Buscar" aria-label="Buscar">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                            <img src="images/search-icon.png" alt="Buscar" class="search-icon">
                        </button>
                    </form>
                </div>
            </div>
        </nav>
    </header>

    <!-- Sección de introducción -->
    <!-- Sección de introducción -->
<section class="intro-section text-center">
    <div class="container">
        <h2 class="mb-4" style="color: #01040d;">Bienvenido a los Servicios de My Startup App</h2>
        <p class="lead mb-5" style="color: #ffffff;">
            En My Startup App, conectamos tu startup con las mejores incubadoras, aceleradoras e inversores ángel acreditados en Perú. 
            Nuestro objetivo es ayudarte a encontrar el apoyo necesario para que tu proyecto crezca y prospere. Explora las opciones 
            disponibles y descubre el asesoramiento y los recursos que estas organizaciones pueden ofrecerte.
        </p>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100 service-card">
                    <div class="card-body">
                        <h5 class="card-title" style="color: #6e8efb;">Incubadoras</h5>
                        <p class="card-text" style="color: #333;">
                            Las incubadoras te ofrecen el soporte inicial necesario para desarrollar tu idea de negocio. 
                            Con su ayuda, podrás acceder a mentoría, espacios de trabajo, y recursos esenciales para dar tus primeros pasos.
                        </p>
                        <a href="services.html?filter=incubadora" class="btn btn-primary">Explorar Incubadoras</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100 service-card">
                    <div class="card-body">
                        <h5 class="card-title" style="color: #6e8efb;">Aceleradoras</h5>
                        <p class="card-text" style="color: #333;">
                            Las aceleradoras te ayudan a escalar tu negocio rápidamente. Con programas intensivos de crecimiento, 
                            podrás mejorar tu modelo de negocio, atraer inversión y ampliar tu mercado.
                        </p>
                        <a href="services.html?filter=aceleradora" class="btn btn-primary">Explorar Aceleradoras</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100 service-card">
                    <div class="card-body">
                        <h5 class="card-title" style="color: #6e8efb;">Inversores Ángel</h5>
                        <p class="card-text" style="color: #333;">
                            Los inversores ángel proporcionan el capital que necesitas para lanzar y expandir tu startup. 
                            Además de la inversión financiera, ofrecen asesoramiento y contactos clave para tu éxito.
                        </p>
                        <a href="services.html?filter=inversión angel" class="btn btn-primary">Explorar Inversores Ángel</a>
                    </div>
                </div>
            </div>
        </div>
        <p class="mt-5" style="color: #6e8efb;">
            ¡No esperes más! Encuentra el apoyo adecuado y lleva tu startup al siguiente nivel con My Startup App.
        </p>
    </div>
</section>


    <!-- Sección de todos los servicios -->
    <div class="container mt-5">
        <h2 class="text-center">Todos los Servicios</h2>
        <form id="filter-form" class="text-center mb-4">
            <label for="service-type">Tipo de Servicio:</label>
            <select id="service-type" name="service-type" class="ml-2">
                <option value="incubadora">Incubadora</option>
                <option value="aceleradora">Aceleradora</option>
                <option value="inversión angel">Inversión Angel</option>
            </select>
            <button type="button" class="btn btn-primary ml-2" onclick="filterServices()">Filtrar</button>
        </form>
        <div id="services-container" class="row">
            <!-- Aquí se cargarán los servicios filtrados -->
        </div>
    </div>

    <!-- Sección de testimonios -->
    <section class="testimonials py-5 bg-light">
        <div class="container">
            <h2 class="text-center">Testimonios</h2>
            <div class="row mt-4">
                <?php include 'php/testimonios.php'; ?>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <h3 class="text-center">Deja tu Testimonio</h3>
                    <form method="POST" action="php/add_testimonio.php">
                        <div class="form-group">
                            <label for="testimonio">Tu Testimonio</label>
                            <textarea class="form-control" id="testimonio" name="testimonio" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Enviar</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    

    <!-- Recursos educativos -->
    <section class="resources py-5">
        <div class="container">
            <h2 class="text-center">Recursos Educativos</h2>
            <p class="text-center">Aprende más sobre cómo aprovechar al máximo los servicios disponibles para startups.</p>
            <ul class="list-unstyled text-center">
                <li><a href="#">¿Qué es una incubadora y cómo puede ayudarte?</a></li>
                <li><a href="#">Beneficios de una aceleradora para tu startup</a></li>
                <li><a href="#">Todo lo que necesitas saber sobre la inversión angel</a></li>
            </ul>
        </div>
    </section>

    <!-- Barra de contactos, términos y condiciones, y políticas de privacidad -->
    <footer class="footer footer-custom mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Contacto</h5>
                    <p>Email: naceituno@est.unap.edu.pe</p>
                    <p>Teléfono: 923353880</p>
                    <p>Dirección: Av. Principal 123, Puno, Perú</p>
                </div>
                <div class="col-md-4">
                    <h5>Términos y Condiciones</h5>
                    <ul class="list-unstyled">
                        <li><a href="docs/terminos_y_condiciones.pdf" target="_blank">Términos de Servicio</a></li>
                        <li><a href="docs/Politica_de_Privacidad.pdf" target="_blank">Política de Privacidad</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Síguenos</h5>
                    <ul class="list-unstyled">
                        <li><a href="#"><img src="images/facebook-icon.png" alt="Facebook" width="20"> Facebook</a></li>
                        <li><a href="#"><img src="images/twitter-icon.png" alt="Twitter" width="20"> Twitter</a></li>
                        <li><a href="#"><img src="images/linkedin-icon.png" alt="LinkedIn" width="20"> LinkedIn</a></li>
                    </ul>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col text-center">
                    <p>&copy; 2024 My Startup App. Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        const services = [
            {id: '1AB', nombre: '1551 Incubadora de Empresas Innovadoras de la UNMSM', tipo: 'Incubadora', web: 'https://1551.unmsm.edu.pe/', email: '1551@unmsm.edu.pe', region: 'Lima'},
            {id: '2CD', nombre: 'ACM Ventures', tipo: 'Incubadora', web: 'https://www.acmventures.com.pe/', email: 'acmventures@acmperu.com.pe', region: 'Lima'},
            {id: '3EF', nombre: 'ACM Ventures', tipo: 'Aceleradora', web: 'https://www.acmventures.com.pe/', email: 'acmventures@acmperu.com.pe', region: 'Lima'},
            {id: '4GH', nombre: 'Bioincuba', tipo: 'Incubadora', web: 'http://www.bioincuba.com', email: 'proyectos@bioincuba.com', region: 'Lima'},
            {id: '5IJ', nombre: 'Incuba UNACH', tipo: 'Incubadora', web: 'https://incubaunach.com/', email: 'dirincubadora@unach.edu.pe', region: 'Cajamarca'},
            {id: '6KL', nombre: 'Emprende UP', tipo: 'Incubadora', web: 'http://emprendeup.pe/', email: 'incubacion@up.edu.pe', region: 'Lima'},
            {id: '7MN', nombre: 'Emprende UP', tipo: 'Aceleradora', web: 'http://emprendeup.pe/', email: 'incubacion@up.edu.pe', region: 'Lima'},
            {id: '8OP', nombre: 'Emprende UP', tipo: 'Inversión Angel', web: 'http://emprendeup.pe/', email: 'incubacion@up.edu.pe', region: 'Lima'},
            {id: '9QR', nombre: 'Endeavor Perú', tipo: 'Aceleradora', web: 'http://endeavor.org.pe/', email: 'info.peru@endeavor.org', region: 'Lima'},
            {id: '10ST', nombre: 'Endeavor Perú', tipo: 'Inversión Angel', web: 'http://endeavor.org.pe/', email: 'info.peru@endeavor.org', region: 'Lima'},
            {id: '11UV', nombre: 'HUB UDEP', tipo: 'Incubadora', web: 'http://hub.udep.pe/', email: 'info@hub.udep.pe', region: 'Piura'},
            {id: '12WX', nombre: 'Incuba UNAM - Universidad Nacional de Moquegua', tipo: 'Incubadora', web: 'https://incuba.unam.edu.pe/', email: 'proyectoincubadora@unam.edu.pe', region: 'Moquegua'},
            {id: '13YZ', nombre: 'Incubagraria', tipo: 'Incubadora', web: 'http://incubagraria.lamolina.edu.pe/', email: 'incubagraria@lamolina.edu.pe', region: 'Lima'},
            {id: '14AB', nombre: 'IncubaUNT: Centro de Emprendimiento e Innovación de la Universidad Nacional de Trujillo', tipo: 'Incubadora', web: 'https://www.facebook.com/incubaunt.peru', email: 'incubaunt@unitru.edu.pe', region: 'Trujillo'},
            {id: '15CD', nombre: 'JAKU Emprende UNSA', tipo: 'Incubadora', web: 'http://www.facebook.com/jakuemprendeunsa', email: 'emprende@unsa.edu.pe', region: 'Arequipa'},
            {id: '16EF', nombre: 'Kaman UCSP', tipo: 'Incubadora', web: 'https://ucsp.edu.pe/kaman', email: 'incubadora@ucsp.edu.pe', region: 'Arequipa'},
            {id: '17GH', nombre: 'LIQUID Venture Studio', tipo: 'Aceleradora', web: 'https://lvs.meetliquid.com/', email: 'info.lvs@meetliquid.com', region: 'Lima'},
            {id: '18IJ', nombre: 'NESsT', tipo: 'Incubadora', web: 'https://www.nesst.org/region-andina', email: 'peru@nesst.org', region: 'Lima'},
            {id: '19KL', nombre: 'NESsT', tipo: 'Aceleradora', web: 'https://www.nesst.org/region-andina', email: 'peru@nesst.org', region: 'Lima'},
            {id: '20MN', nombre: 'NESsT', tipo: 'Inversión Angel', web: 'https://www.nesst.org/region-andina', email: 'peru@nesst.org', region: 'Lima'},
            {id: '21OP', nombre: 'Nexum: Incubadoras de Empresas PUCP', tipo: 'Incubadora', web: 'https://cide.pucp.edu.pe/incubacion-empresas/', email: 'incubadora@pucp.edu.pe', region: 'Lima'},
            {id: '22QR', nombre: 'S360 - Incubadora de Negocios UPAO', tipo: 'Incubadora', web: 'https://s360.pe/', email: 's360@upao.edu.pe', region: 'Trujillo'},
            {id: '23ST', nombre: 'Startup UNI', tipo: 'Incubadora', web: 'http://startup.uni.edu.pe/', email: 'startup@uni.edu.pe', region: 'Lima'},
            {id: '24UV', nombre: 'StartUPC', tipo: 'Incubadora', web: 'http://upc.pe/startupc', email: 'incubadora@upc.pe', region: 'Lima'},
            {id: '25WX', nombre: 'StartUPC', tipo: 'Aceleradora', web: 'http://upc.pe/startupc', email: 'incubadora@upc.pe', region: 'Lima'},
            {id: '26YZ', nombre: 'UPT INCUBA Aruntakana - Universidad Privada de Tacna', tipo: 'Incubadora', web: 'https://uptincuba.pe/', email: 'incubadora@upt.pe', region: 'Tacna'},
            {id: '27AB', nombre: 'USIL Ventures', tipo: 'Incubadora', web: 'http://www.usilventures.com', email: 'usilventures@usil.edu.pe', region: 'Lima'},
            {id: '28CD', nombre: 'USIL Ventures', tipo: 'Aceleradora', web: 'http://www.usilventures.com', email: 'usilventures@usil.edu.pe', region: 'Lima'},
            {id: '29EF', nombre: 'UTEC Ventures', tipo: 'Aceleradora', web: 'http://utecventures.com/', email: 'ventures@utec.edu.pe', region: 'Lima'},
            {id: '30GH', nombre: 'UTEC Ventures', tipo: 'Inversión Angel', web: 'http://utecventures.com/', email: 'ventures@utec.edu.pe', region: 'Lima'},
            {id: '31IJ', nombre: 'Wichay - Universidad Continental', tipo: 'Incubadora', web: 'http://www.wichay.pe', email: 'wichay@continental.edu.pe', region: 'Huancayo'},
            {id: '32KL', nombre: 'Zsport Lab', tipo: 'Incubadora', web: 'http://www.zsports.com.pe/', email: 'lab@zsports.com.pe', region: 'Lima'},
            {id: '33MN', nombre: 'Cajamarca Incuba - Cámara de Comercio y Producción de Cajamarca', tipo: 'Incubadora', web: 'https://camcajamarca.com.pe/cajamarca-incuba/', email: 'mmendoza@recursossa.com', region: 'Cajamarca'},
            {id: '34OP', nombre: 'SCALE', tipo: 'Pre-Incubación', web: 'http://www.scaleup4.com', email: 'proyectos@scaleup4.com', region: 'Lima'},
            {id: '35QR', nombre: 'SCALE', tipo: 'Incubación', web: 'http://www.scaleup4.com', email: 'proyectos@scaleup4.com', region: 'Lima'},
            {id: '36ST', nombre: 'INNICIA - Universidad Católica Santa María', tipo: 'Pre-Incubación', web: 'http://investigacion.ucsm.edu.pe/innicia/', email: 'innicia@ucsm.edu.pe', region: 'Arequipa'},
            {id: '37UV', nombre: 'INNICIA - Universidad Católica Santa María', tipo: 'Incubación', web: 'http://investigacion.ucsm.edu.pe/innicia/', email: 'innicia@ucsm.edu.pe', region: 'Arequipa'},
            {id: '38WX', nombre: 'INNOVAUL - Universidad de Lima', tipo: 'Incubadora', web: 'http://InnovaUL', email: 'emprendimiento@ulima.edu.pe', region: 'Lima'},
            {id: '39YZ', nombre: 'INNOVAUL - Universidad de Lima', tipo: 'Aceleradora', web: 'http://InnovaUL', email: 'emprendimiento@ulima.edu.pe', region: 'Lima'},
            {id: '40AB', nombre: 'INCUBA UNTUMBES - Universidad Nacional de Tumbes', tipo: 'Incubadora', web: 'http://Incuba UNTTumbes', email: 'incubauntumbes@untumbes.edu.pe', region: 'Tumbes'},
            {id: '41CD', nombre: 'TecnológICA - Cámara de Comercio de Ica', tipo: 'Incubadora', web: 'https://camaraica.org.pe/', email: 'info@ecosistemaica.com', region: 'Ica'},
            {id: '42EF', nombre: 'Incuba UNAS', tipo: 'Incubadora', web: 'https://www.facebook.com/INCUBAUNAS', email: 'incubaunas@unas.edu.pe', region: 'Huánuco'},
            {id: '43GH', nombre: 'Paqarina Wasi UNSAAC', tipo: 'Incubadora', web: 'https://www.facebook.com/paqarinawasi/', email: 'paqarinawasi@unsaac.edu.pe', region: 'Cusco'},
        ];

        function filterServices() {
            const serviceType = document.getElementById('service-type').value;
            const filteredServices = services.filter(service => service.tipo.toLowerCase() === serviceType.toLowerCase());
            const container = document.getElementById('services-container');
            container.innerHTML = '';
            filteredServices.forEach(service => {
                const serviceElement = document.createElement('div');
                serviceElement.classList.add('col-md-4', 'mb-4');
                serviceElement.innerHTML = `
                    <div class="card h-100 service-card">
                        <div class="card-body">
                            <h5 class="card-title">${service.nombre}</h5>
                            <p class="card-text"><strong>Tipo:</strong> ${service.tipo}</p>
                            <p class="card-text"><strong>Email:</strong> ${service.email}</p>
                            <p class="card-text"><strong>Región:</strong> ${service.region}</p>
                            <a href="${service.web}" class="btn btn-primary" target="_blank">Ver más</a>
                        </div>
                    </div>
                `;
                container.appendChild(serviceElement);
            });
        }

        document.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const filter = urlParams.get('filter');
            if (filter) {
                document.getElementById('service-type').value = filter;
                filterServices();
            }

            // Cargar servicios destacados
            const featuredContainer = document.getElementById('featured-services');
            const featuredServices = services.slice(0, 3); // Seleccionar los primeros 3 servicios como destacados
            featuredServices.forEach(service => {
                const serviceElement = document.createElement('div');
                serviceElement.classList.add('col-md-4', 'mb-4');
                serviceElement.innerHTML = `
                    <div class="card h-100 service-card">
                        <div class="card-body">
                            <h5 class="card-title">${service.nombre}</h5>
                            <p class="card-text"><strong>Tipo:</strong> ${service.tipo}</p>
                            <p class="card-text"><strong>Email:</strong> ${service.email}</p>
                            <p class="card-text"><strong>Región:</strong> ${service.region}</p>
                            <a href="${service.web}" class="btn btn-primary" target="_blank">Ver más</a>
                        </div>
                    </div>
                `;
                featuredContainer.appendChild(serviceElement);
            });
        });
    </script>
</body>
</html>

