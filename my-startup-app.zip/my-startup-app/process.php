<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = [
        'name' => $_POST['name'],
        'sector' => $_POST['sector'],
        'popularity' => $_POST['popularity'],
        'growthTime' => $_POST['growthTime'],
        'region' => $_POST['region']
    ];

    $file = $_FILES['file'];

    // Verificar que el archivo subido sea un PDF
    if ($file['type'] !== 'application/pdf') {
        echo json_encode(['error' => 'Solo se permiten archivos PDF']);
        exit();
    }

    $file_path = $file['tmp_name'];
    $file_name = $file['name'];
    $destination = 'pdf_uploads/' . $file_name;

    // Mover el archivo subido a la carpeta de destino
    if (!move_uploaded_file($file_path, $destination)) {
        echo json_encode(['error' => 'Error al mover el archivo PDF']);
        exit();
    }

    $curl = curl_init();

    $post_fields = array_merge($data, [
        'file' => new CURLFile($destination, $file['type'], $file_name)
    ]);

    curl_setopt_array($curl, [
        CURLOPT_URL => 'http://127.0.0.1:5000/predict',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $post_fields,
    ]);

    $response = curl_exec($curl);
    $curl_error = curl_error($curl);
    curl_close($curl);

    if ($response === false) {
        echo json_encode(['error' => 'Error en la solicitud CURL: ' . $curl_error]);
        exit();
    }

    header('Content-Type: application/json');
    echo $response;
}
?>





