<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>My Startup App</title>
    <style>
        /* General Navbar Styles */
        .navbar {
            background-color: #f8f9fa;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .logo-navbar {
            height: 50px;
        }

        /* Navbar Links */
        .nav-link {
            color: #555;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 20px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .nav-link:hover {
            color: white;
            background-color: #ffbbcc; /* Soft pink */
        }

        .login-btn {
            background-color: #bbd4ff; /* Light blue */
            color: white;
        }

        .login-btn:hover {
            background-color: #99bbff; /* Darker blue */
        }

        /* Dropdown Menu */
        .dropdown-menu {
            background-color: #ffe6e6; /* Soft red */
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .dropdown-item {
            color: #555;
            padding: 10px 20px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .dropdown-item:hover {
            color: white;
            background-color: #ffbbcc; /* Soft pink */
        }

        /* Search Form */
        .form-inline .form-control {
            border-radius: 20px;
            border: 1px solid #ced4da;
        }

        .form-inline .btn {
            border: none;
            background: none;
        }

        .search-icon {
            width: 20px;
            height: 20px;
        }
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="../images/logo.png" alt="Logo" class="logo-navbar">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link nav-btn" href="index.html">INICIO</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle nav-btn" href="#" id="servicesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                SERVICIO
                            </a>
                            <div class="dropdown-menu" aria-labelledby="servicesDropdown">
                                <a class="dropdown-item" href="services.html?filter=incubadora">Incubadora</a>
                                <a class="dropdown-item" href="services.html?filter=aceleradora">Aceleradora</a>
                                <a class="dropdown-item" href="services.html?filter=inversion-angel">Inversión Angel</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn" href="investment.html">INVERSIÓN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn" href="contact.html">CONTACTOS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn login-btn" href="login.php">LOGIN</a>
                        </li>
                    </ul>
                    <form class="form-inline ml-3">
                        <input class="form-control mr-sm-2" type="search" placeholder="Buscar" aria-label="Buscar">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                            <img src="../images/search-icon.png" alt="Buscar" class="search-icon">
                        </button>
                    </form>
                </div>
            </div>
        </nav>
    </header>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
