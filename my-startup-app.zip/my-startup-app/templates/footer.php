<footer class="footer footer-custom mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Contacto</h5>
                    <p>Email: naceituno@est.unap.edu.pe</p>
                    <p>Teléfono: 923353880</p>
                    <p>Dirección: Av. Principal 123, Puno, Perú</p>
                </div>
                <div class="col-md-4">
                    <h5>Términos y Condiciones</h5>
                    <ul class="list-unstyled">
                        <li><a href="docs/terminos_y_condiciones.pdf" target="_blank">Términos de Servicio</a></li>
                        <li><a href="docs/Politica_de_Privacidad.pdf" target="_blank">Política de Privacidad</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Síguenos</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://web.facebook.com/profile.php?id=100069060834241&sk=about"><img src="images/facebook-icon.png" alt="Facebook" width="20"> Facebook</a></li>
                        <li><a href="#"><img src="images/twitter-icon.png" alt="Twitter" width="20"> Twitter</a></li>
                        <li><a href="https://www.linkedin.com/onboarding/start"><img src="images/linkedin-icon.png" alt="LinkedIn" width="20"> LinkedIn</a></li>
                    </ul>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col text-center">
                    <p>&copy; 2024 My Startup App. Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
    </footer>

