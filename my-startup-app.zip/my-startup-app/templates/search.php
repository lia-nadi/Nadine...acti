<?php
// search.php

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_startup_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el término de búsqueda
$query = isset($_GET['query']) ? $_GET['query'] : '';

// Escapar el término de búsqueda para evitar inyecciones SQL
$query = $conn->real_escape_string($query);

// Consulta a la base de datos
$sql = "SELECT * FROM startups WHERE name LIKE '%$query%' OR description LIKE '%$query%' OR category LIKE '%$query%'";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de búsqueda</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Resultados de búsqueda para "<?php echo htmlspecialchars($query); ?>"</h1>
        <div class="list-group">
            <?php
            if ($result->num_rows > 0) {
                // Mostrar los resultados de búsqueda
                while ($row = $result->fetch_assoc()) {
                    echo '<a href="startup_detail.php?id=' . $row['id'] . '" class="list-group-item list-group-item-action">';
                    echo '<h5 class="mb-1">' . $row['name'] . '</h5>';
                    echo '<p class="mb-1">' . $row['description'] . '</p>';
                    echo '<small>' . $row['category'] . '</small>';
                    echo '</a>';
                }
            } else {
                echo '<p class="text-muted">No se encontraron resultados.</p>';
            }
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.0/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
