<?php
// Conexión a la base de datos
$conn = new mysqli('localhost', 'root', '', 'my_startup_app');

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los testimonios de la base de datos
$sql = "SELECT t.comment, u.name FROM testimonials t JOIN users u ON t.user_id = u.id";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Mostrar cada testimonio
    while ($row = $result->fetch_assoc()) {
        echo '<div class="col-md-4">';
        echo '<div class="testimonial p-3">';
        echo '<p>"' . htmlspecialchars($row['comment']) . '"</p>';
        echo '<p><strong>- ' . htmlspecialchars($row['name']) . '</strong></p>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo '<div class="col-md-12"><p class="text-center">No hay testimonios aún.</p></div>';
}

$conn->close();
?>
