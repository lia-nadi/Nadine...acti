<?php
// Configuración de reportes de errores
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'my_startup_app';

try {
    // Crear conexión
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8mb4"); // Establecer el conjunto de caracteres
} catch (mysqli_sql_exception $e) {
    // Manejar errores de conexión
    error_log($e->getMessage());
    exit('Error connecting to database'); // No revelar detalles específicos de la conexión
}
?>
