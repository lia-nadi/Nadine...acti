<?php
include '../config.php';

$type = $_GET['type'];

$sql = "SELECT * FROM services WHERE tipo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $type);
$stmt->execute();
$result = $stmt->get_result();

$services = array();
while ($row = $result->fetch_assoc()) {
    $services[] = $row;
}

echo json_encode($services);

$stmt->close();
$conn->close();
?>
