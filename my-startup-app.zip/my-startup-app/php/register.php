<?php
session_start();

// Mostrar errores solo en desarrollo
if (getenv('APP_ENV') === 'development') {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener datos del formulario y sanitizarlos
    $dni = filter_var($_POST['dni'], FILTER_SANITIZE_STRING);
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    // Validación de contraseñas
    if ($password !== $password_confirm) {
        $_SESSION['error'] = "Las contraseñas no coinciden.";
        header("Location: ../index.php");
        exit();
    }

    // Encriptar la contraseña
    $password_hashed = password_hash($password, PASSWORD_BCRYPT);

    // Verificar si el correo ya está registrado
    $stmt = $conn->prepare("SELECT dni FROM users WHERE email = ?");
    if ($stmt === false) {
        error_log("Error en la preparación: " . $conn->error);
        $_SESSION['error'] = "Error en el registro.";
        header("Location: ../index.php");
        exit();
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['error'] = "El correo electrónico ya está registrado.";
        $stmt->close();
        header("Location: ../index.php");
        exit();
    }

    $stmt->close();

    // Registrar nuevo usuario
    $stmt = $conn->prepare("INSERT INTO users (dni, name, email, password) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        error_log("Error en la preparación: " . $conn->error);
        $_SESSION['error'] = "Error en el registro.";
        header("Location: ../index.php");
        exit();
    }
    $stmt->bind_param("ssss", $dni, $name, $email, $password_hashed);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $_SESSION['success'] = "Registro exitoso.";
        header("Location: ../login.php");
        exit();
    } else {
        $_SESSION['error'] = "Error en el registro.";
    }

    $stmt->close();
}

$conn->close();
header("Location: ../login.php");
exit();
?>

