<?php
include 'config.php';

if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);
    exit('Error connecting to database'); // Mensaje genérico
} else {
    echo "Connected successfully";
}

$conn->close();
?>
