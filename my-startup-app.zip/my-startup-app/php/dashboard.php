<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Obtener el nombre del usuario desde la sesión
$user_name = $_SESSION['user_name'];

// Obtener más detalles del usuario desde la base de datos (ejemplo)
// Conexión a la base de datos
$conn = new mysqli('localhost', 'root', '', 'my_startup_app');

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT email FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($user_email);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - My Startup App</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .navbar-brand img {
            height: 40px;
        }
        .welcome {
            text-align: center;
            margin-top: 50px;
        }
        .card {
            margin: 20px;
        }
        .footer {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 10px;
        }
        .nav-item .dropdown-menu {
            right: 0;
            left: auto;
        }
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="../index.html">
                    <img src="../images/logo.png" alt="Logo" class="logo-navbar">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link nav-btn" href="../index.html">Inicio</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle nav-btn" href="#" id="servicesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Servicio
                            </a>
                            <div class="dropdown-menu" aria-labelledby="servicesDropdown">
                                <a class="dropdown-item" href="../services.html?filter=incubadora">Incubadora</a>
                                <a class="dropdown-item" href="../services.html?filter=aceleradora">Aceleradora</a>
                                <a class="dropdown-item" href="../services.html?filter=inversion-angel">Inversión Angel</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn" href="../investment.html">Inversión</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-btn" href="../contact.html">Contactos</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle nav-btn" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo htmlspecialchars($user_name); ?>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="profile.php">Perfil</a>
                                <a class="dropdown-item" href="logout.php">Cerrar sesión</a>
                            </div>
                        </li>
                    </ul>
                    <form class="form-inline ml-3">
                        <input class="form-control mr-sm-2" type="search" placeholder="Buscar" aria-label="Buscar">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                            <img src="../images/search-icon.png" alt="Buscar" class="search-icon">
                        </button>
                    </form>
                </div>
            </div>
        </nav>
    </header>

    <!-- Contenido del Dashboard -->
    <div class="container welcome">
        <h1 class="mb-4">Bienvenido, <?php echo htmlspecialchars($user_name); ?>!</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        Perfil de Usuario
                    </div>
                    <div class="card-body">
                        <p>Nombre: <?php echo htmlspecialchars($user_name); ?></p>
                        <p>Email: <?php echo htmlspecialchars($user_email); ?></p>
                        <a href="edit_profile.php" class="btn btn-primary">Editar Perfil</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        Operaciones Básicas
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <a href="../contact.html" class="list-group-item list-group-item-action">Contacto</a>
                            <a href="../investment.html" class="list-group-item list-group-item-action">Inversión</a>
                            <a href="../services.html" class="list-group-item list-group-item-action">Servicios</a>
                            <a href="security.php" class="list-group-item list-group-item-action">Seguridad</a>
                            <a href="settings.php" class="list-group-item list-group-item-action">Configuraciones</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <small>Derechos reservados &copy; My Startup App 2024</small>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

