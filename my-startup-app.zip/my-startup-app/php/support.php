<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $issue = $_POST['issue'];
    
    $stmt = $conn->prepare("INSERT INTO support (issue) VALUES (?)");
    $stmt->bind_param("s", $issue);

    if ($stmt->execute()) {
        echo "Su problema ha sido enviado!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
