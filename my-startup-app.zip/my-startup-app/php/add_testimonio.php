<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $comment = trim($_POST['testimonio']);

    // Conexión a la base de datos
    $conn = new mysqli('localhost', 'root', '', 'my_startup_app');

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Insertar el testimonio en la base de datos
    $sql = "INSERT INTO testimonials (user_id, comment) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error en la preparación de la consulta SQL: " . $conn->error);
    }
    $stmt->bind_param("is", $user_id, $comment);
    if ($stmt->execute()) {
        $_SESSION['message'] = "¡Tu testimonio ha sido enviado exitosamente!";
    } else {
        $_SESSION['error'] = "Hubo un error al enviar tu testimonio. Por favor, inténtalo de nuevo.";
    }
    $stmt->close();
    $conn->close();

    header("Location: ../services.php");  // Cambia la redirección a la página correcta
    exit();
} else {
    header("Location: ../services.php");  // Cambia la redirección a la página correcta
    exit();
}
