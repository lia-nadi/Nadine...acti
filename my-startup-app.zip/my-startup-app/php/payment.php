<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Configuración de la API
    $api_url = 'https://api.izipay.com/payment';
    $api_key = 'YOUR_API_KEY_HERE'; // Sustituye con tu clave API

    // Datos de la transacción
    $amount = $_POST['amount']; // Asumiendo que el monto viene del formulario
    $currency = 'USD'; // Puedes hacer esto dinámico según tu necesidad

    $data = array(
        'amount' => $amount * 100, // Convertir a centavos
        'currency' => $currency
    );

    $options = array(
        'http' => array(
            'header'  => "Content-Type: application/json\r\n" .
                         "Authorization: Bearer " . $api_key . "\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
        ),
    );

    $context  = stream_context_create($options);
    $result = file_get_contents($api_url, false, $context);

    if ($result === FALSE) {
        die('Error');
    }

    // Procesar el resultado de la API
    $response = json_decode($result, true);
    if ($response['status'] == 'success') {
        echo "Pago realizado con éxito!";
    } else {
        echo "Error en el pago: " . $response['message'];
    }
}
?>
